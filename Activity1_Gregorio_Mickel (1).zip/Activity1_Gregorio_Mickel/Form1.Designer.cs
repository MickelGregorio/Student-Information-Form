﻿namespace Activity1_Gregorio_Mickel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtbox_MiddleInitial = new System.Windows.Forms.TextBox();
            this.txtbox_LastName = new System.Windows.Forms.TextBox();
            this.txtbox_FirstName = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.Label();
            this.MiddleInitial = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtbox_BlkLot = new System.Windows.Forms.TextBox();
            this.txtbox_Subdivision = new System.Windows.Forms.TextBox();
            this.txtbox_Barangay = new System.Windows.Forms.TextBox();
            this.txtbox_Municipality = new System.Windows.Forms.TextBox();
            this.BlkLot = new System.Windows.Forms.Label();
            this.Subdivision = new System.Windows.Forms.Label();
            this.Barangay = new System.Windows.Forms.Label();
            this.Municipality = new System.Windows.Forms.Label();
            this.Province = new System.Windows.Forms.Label();
            this.txtbox_Province = new System.Windows.Forms.TextBox();
            this.performanceCounter1 = new System.Diagnostics.PerformanceCounter();
            this.cbCourse = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbox_StudentNumber = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtbox_MiddleInitial
            // 
            this.txtbox_MiddleInitial.Location = new System.Drawing.Point(140, 97);
            this.txtbox_MiddleInitial.Name = "txtbox_MiddleInitial";
            this.txtbox_MiddleInitial.Size = new System.Drawing.Size(100, 20);
            this.txtbox_MiddleInitial.TabIndex = 2;
            this.txtbox_MiddleInitial.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtbox_LastName
            // 
            this.txtbox_LastName.Location = new System.Drawing.Point(140, 45);
            this.txtbox_LastName.Name = "txtbox_LastName";
            this.txtbox_LastName.Size = new System.Drawing.Size(100, 20);
            this.txtbox_LastName.TabIndex = 0;
            this.txtbox_LastName.TextChanged += new System.EventHandler(this.txtbox_Gregorio_TextChanged);
            // 
            // txtbox_FirstName
            // 
            this.txtbox_FirstName.Location = new System.Drawing.Point(140, 71);
            this.txtbox_FirstName.Name = "txtbox_FirstName";
            this.txtbox_FirstName.Size = new System.Drawing.Size(100, 20);
            this.txtbox_FirstName.TabIndex = 1;
            // 
            // LastName
            // 
            this.LastName.AutoSize = true;
            this.LastName.Location = new System.Drawing.Point(79, 48);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(55, 13);
            this.LastName.TabIndex = 5;
            this.LastName.Text = "LastName";
            // 
            // FirstName
            // 
            this.FirstName.AutoSize = true;
            this.FirstName.Location = new System.Drawing.Point(79, 78);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(54, 13);
            this.FirstName.TabIndex = 6;
            this.FirstName.Text = "FirstName";
            // 
            // MiddleInitial
            // 
            this.MiddleInitial.AutoSize = true;
            this.MiddleInitial.Location = new System.Drawing.Point(79, 104);
            this.MiddleInitial.Name = "MiddleInitial";
            this.MiddleInitial.Size = new System.Drawing.Size(62, 13);
            this.MiddleInitial.TabIndex = 7;
            this.MiddleInitial.Text = "MiddleInitial";
            this.MiddleInitial.Click += new System.EventHandler(this.Gregorio_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(140, 256);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtbox_BlkLot
            // 
            this.txtbox_BlkLot.Location = new System.Drawing.Point(141, 126);
            this.txtbox_BlkLot.Name = "txtbox_BlkLot";
            this.txtbox_BlkLot.Size = new System.Drawing.Size(100, 20);
            this.txtbox_BlkLot.TabIndex = 3;
            // 
            // txtbox_Subdivision
            // 
            this.txtbox_Subdivision.Location = new System.Drawing.Point(141, 152);
            this.txtbox_Subdivision.Name = "txtbox_Subdivision";
            this.txtbox_Subdivision.Size = new System.Drawing.Size(100, 20);
            this.txtbox_Subdivision.TabIndex = 4;
            // 
            // txtbox_Barangay
            // 
            this.txtbox_Barangay.Location = new System.Drawing.Point(141, 178);
            this.txtbox_Barangay.Name = "txtbox_Barangay";
            this.txtbox_Barangay.Size = new System.Drawing.Size(100, 20);
            this.txtbox_Barangay.TabIndex = 5;
            // 
            // txtbox_Municipality
            // 
            this.txtbox_Municipality.Location = new System.Drawing.Point(141, 204);
            this.txtbox_Municipality.Name = "txtbox_Municipality";
            this.txtbox_Municipality.Size = new System.Drawing.Size(100, 20);
            this.txtbox_Municipality.TabIndex = 6;
            // 
            // BlkLot
            // 
            this.BlkLot.AutoSize = true;
            this.BlkLot.Location = new System.Drawing.Point(87, 133);
            this.BlkLot.Name = "BlkLot";
            this.BlkLot.Size = new System.Drawing.Size(42, 13);
            this.BlkLot.TabIndex = 12;
            this.BlkLot.Text = "Blk/Lot";
            this.BlkLot.Click += new System.EventHandler(this.label1_Click);
            // 
            // Subdivision
            // 
            this.Subdivision.AutoSize = true;
            this.Subdivision.Location = new System.Drawing.Point(81, 159);
            this.Subdivision.Name = "Subdivision";
            this.Subdivision.Size = new System.Drawing.Size(61, 13);
            this.Subdivision.TabIndex = 13;
            this.Subdivision.Text = "Subdivision";
            // 
            // Barangay
            // 
            this.Barangay.AutoSize = true;
            this.Barangay.Location = new System.Drawing.Point(83, 185);
            this.Barangay.Name = "Barangay";
            this.Barangay.Size = new System.Drawing.Size(52, 13);
            this.Barangay.TabIndex = 14;
            this.Barangay.Text = "Barangay";
            // 
            // Municipality
            // 
            this.Municipality.AutoSize = true;
            this.Municipality.Location = new System.Drawing.Point(80, 207);
            this.Municipality.Name = "Municipality";
            this.Municipality.Size = new System.Drawing.Size(62, 13);
            this.Municipality.TabIndex = 15;
            this.Municipality.Text = "Municipality";
            // 
            // Province
            // 
            this.Province.AutoSize = true;
            this.Province.Location = new System.Drawing.Point(84, 233);
            this.Province.Name = "Province";
            this.Province.Size = new System.Drawing.Size(49, 13);
            this.Province.TabIndex = 16;
            this.Province.Text = "Province";
            this.Province.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtbox_Province
            // 
            this.txtbox_Province.Location = new System.Drawing.Point(141, 230);
            this.txtbox_Province.Name = "txtbox_Province";
            this.txtbox_Province.Size = new System.Drawing.Size(100, 20);
            this.txtbox_Province.TabIndex = 7;
            // 
            // cbCourse
            // 
            this.cbCourse.FormattingEnabled = true;
            this.cbCourse.Items.AddRange(new object[] {
            "Bachelor of Science in Information Technology",
            "Bachelor of Science in Psychology",
            "Bachelor of Science in Nursing",
            "Bachelor of Science in Medical Technology",
            "Bachelor of Arts in Communication",
            "Bachelor of Science of Hospitality Management",
            "Bachelor of Science in Accountancy",
            "Bachelor of Science in Business Administration",
            "Bachelor of Science in Tourism Management"});
            this.cbCourse.Location = new System.Drawing.Point(385, 15);
            this.cbCourse.Name = "cbCourse";
            this.cbCourse.Size = new System.Drawing.Size(121, 21);
            this.cbCourse.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(344, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Course";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label1.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "StudentNumber";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtbox_StudentNumber
            // 
            this.txtbox_StudentNumber.Location = new System.Drawing.Point(140, 19);
            this.txtbox_StudentNumber.Name = "txtbox_StudentNumber";
            this.txtbox_StudentNumber.Size = new System.Drawing.Size(100, 20);
            this.txtbox_StudentNumber.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 526);
            this.Controls.Add(this.txtbox_StudentNumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbCourse);
            this.Controls.Add(this.txtbox_Province);
            this.Controls.Add(this.Province);
            this.Controls.Add(this.Municipality);
            this.Controls.Add(this.Barangay);
            this.Controls.Add(this.Subdivision);
            this.Controls.Add(this.BlkLot);
            this.Controls.Add(this.txtbox_Municipality);
            this.Controls.Add(this.txtbox_Barangay);
            this.Controls.Add(this.txtbox_Subdivision);
            this.Controls.Add(this.txtbox_BlkLot);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.MiddleInitial);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.txtbox_FirstName);
            this.Controls.Add(this.txtbox_LastName);
            this.Controls.Add(this.txtbox_MiddleInitial);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
         //   ((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbox_MiddleInitial;
        private System.Windows.Forms.TextBox txtbox_LastName;
        private System.Windows.Forms.TextBox txtbox_FirstName;
        private System.Windows.Forms.Label LastName;
        private System.Windows.Forms.Label FirstName;
        private System.Windows.Forms.Label MiddleInitial;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtbox_BlkLot;
        private System.Windows.Forms.TextBox txtbox_Subdivision;
        private System.Windows.Forms.TextBox txtbox_Barangay;
        private System.Windows.Forms.TextBox txtbox_Municipality;
        private System.Windows.Forms.Label BlkLot;
        private System.Windows.Forms.Label Subdivision;
        private System.Windows.Forms.Label Barangay;
        private System.Windows.Forms.Label Municipality;
        private System.Windows.Forms.Label Province;
        private System.Windows.Forms.TextBox txtbox_Province;
        private System.Diagnostics.PerformanceCounter performanceCounter1;
        private System.Windows.Forms.ComboBox cbCourse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbox_StudentNumber;
    }
}

